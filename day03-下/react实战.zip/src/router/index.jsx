import { createBrowserRouter, Navigate, redirect } from "react-router-dom";
import Login from "../pages/Login";
import Home from "../pages/Home";
import Article from "../pages/Article";
import Publish from "../pages/Publish";
// import { lazy } from "react";

// const Article = lazy(() => import("../pages/Article/index.jsx"));
// const Publish = lazy(() => import("../pages/Publish/index.jsx"));

const router = createBrowserRouter([
  // 路由信息
  { path: "/", element: <Navigate to="/home" /> },
  {
    path: "/home",
    element: <Home />,
    loader: () => {
      // 表示路由加载之前的操作
      const userInfo = JSON.parse(localStorage.getItem("user-info") || "{}");
      if (userInfo.token) {
        return null;
      }
      // return <Navigate to="/login" />; // 跳转到登录页
      return redirect("/login");
    },
    children: [
      {
        path: "article",
        element: <Article />,
      },
      {
        path: "publish",
        element: <Publish />,
      },
    ],
  },
  {
    path: "/login",
    element: <Login />,
    loader: () => {
      const userInfo = JSON.parse(localStorage.getItem("user-info") || "{}");
      if (userInfo.token) {
        return redirect("/");
      }
      // return <Navigate to="/login" />; // 跳转到登录页
      return null;
    },
  },
]);

export default router;
