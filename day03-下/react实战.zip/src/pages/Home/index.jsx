import { Link, Outlet } from "react-router-dom";
import {
  UserOutlined,
  VideoCameraOutlined,
  PoweroffOutlined,
} from "@ant-design/icons";
import "./index.css";
import { Layout, Menu, theme, Row, Popconfirm, Avatar } from "antd";
import { useNavigate } from "react-router-dom";
import { getUserInfo } from "../../api/user";
import { useEffect, useState } from "react";
const { Header, Content, Footer, Sider } = Layout;

const App = () => {
  const [userInfo, setUserInfo] = useState({});
  useEffect(() => {
    getUser();
  }, []);
  const getUser = async () => {
    setUserInfo(await getUserInfo()); // 设置用户信息
  };
  const navigate = useNavigate();
  const {
    token: { colorBgContainer },
  } = theme.useToken();
  const logout = () => {
    // 删除token 跳转到登录页
    localStorage.removeItem("user-info");
    navigate("/login");
  };
  return (
    <Layout className="home-container">
      <Sider
        breakpoint="lg"
        collapsedWidth="0"
        onBreakpoint={(broken) => {
          console.log(broken);
        }}
        onCollapse={(collapsed, type) => {
          console.log(collapsed, type);
        }}
      >
        <div className="logo" />
        <Menu
          theme="dark"
          mode="inline"
          defaultSelectedKeys={["4"]}
          //   items={[
          //     UserOutlined,
          //     VideoCameraOutlined,
          //     UploadOutlined,
          //     UserOutlined,
          //   ].map((icon, index) => ({
          //     key: String(index + 1),
          //     icon: React.createElement(icon),
          //     label: `nav ${index + 1}`,
          //   }))}
          items={[
            {
              key: "article",
              icon: <UserOutlined />,
              label: <Link to="/home/article">文章管理</Link>,
            },
            {
              key: "publish",
              icon: <VideoCameraOutlined />,
              label: <Link to="/home/publish">发布文章</Link>,
            },
          ]}
        />
      </Sider>
      <Layout>
        <Header style={{ padding: 0, background: colorBgContainer }}>
          <Row justify="end" align="middle">
            <Avatar src={userInfo.photo}></Avatar>
            <span style={{ marginRight: 10 }}>{userInfo.name}</span>
            <span style={{ fontSize: 20, marginRight: 20 }}>
              <Popconfirm
                title="提示"
                description="确定要退出登录吗"
                onConfirm={logout}
                okText="Yes"
                cancelText="No"
              >
                <PoweroffOutlined />
              </Popconfirm>
            </span>
          </Row>
        </Header>
        <Content style={{ margin: "24px 16px 0" }}>
          <div
            style={{
              padding: 24,
              minHeight: 360,
              background: colorBgContainer,
            }}
          >
            <Outlet />
          </div>
        </Content>
        <Footer style={{ textAlign: "center" }}>
          Ant Design ©2023 Created by Ant UED
        </Footer>
      </Layout>
    </Layout>
  );
};

export default App;
