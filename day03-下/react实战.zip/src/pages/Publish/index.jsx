const Publish = () => {
  return <div>发表文章</div>;
};

export default Publish;
