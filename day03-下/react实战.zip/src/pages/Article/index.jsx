const Article = () => {
  return <div>文章列表</div>;
};

export default Article;
