import axios from "axios";
import { message } from "antd";
import { redirect } from "react-router-dom";
const service = axios.create({
  baseURL: "http://toutiao.itheima.net/v1_0",
  timeout: 10000,
});
// 请求拦截器
service.interceptors.request.use((config) => {
  const userInfo = JSON.parse(localStorage.getItem("user-info") || "{}");

  if (userInfo.token) {
    // 注入token
    config.headers.Authorization = `Bearer ${userInfo.token}`;
  }
  return config;
});
// 相应拦截器
service.interceptors.response.use(
  (response) => {
    // axios默认包了一层data
    // 接口又包了一层data
    return response.data ? response.data.data : response.data;
  },
  async (error) => {
    // token有效期是2个小时  refresh_token的有效期是14天
    if (error.response?.status === 401) {
      // 此时说明token失效
      // 检查有没有refresh_token
      // 如果有 refresh_token 说明还有救 用refresh_token换取新的token
      const userInfo = JSON.parse(localStorage.getItem("user-info") || "{}");
      if (userInfo.refresh_token) {
        try {
          const {
            data: {
              data: { token },
            },
          } = await axios({
            url: "http://toutiao.itheima.net/v1_0/authorizations",
            method: "put",
            headers: {
              Authorization: `Bearer ${userInfo.refresh_token}`, // 传入刷新的token
            },
          });
          // 拿到了新的token 替换本地缓存中的token
          localStorage.setItem(
            "user-info",
            JSON.stringify({ ...userInfo, token })
          );
          return service(error.config); // 重新发起之前错误的请求
        } catch (error) {
          localStorage.removeItem("user-info");
          // refresh_token也失效了
          window.location.href = "/login";
          // 跳转到登录页
          return Promise.reject(new Error("token超时"));
        }
      } else {
        window.location.href = "/login";
        localStorage.removeItem("user-info");

        // 跳转到登录页
        return Promise.reject(new Error("token超时"));
      }
    }
    message.error(error.message);
    return Promise.reject(error);
  }
);
export default service;
